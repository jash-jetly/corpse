"""
Handwritten Character Recognition — Drawing App

A Pygame desktop application where users draw characters on a black canvas
with white strokes. The app preprocesses the drawing and predicts the
character using a trained CNN model (digits, uppercase, lowercase).

Controls:
    - Draw with mouse (left button)
    - Press 'C' to clear the canvas
    - Press 'Q' or close window to quit

Usage:
    python app.py
"""

import sys
import os
import time

import numpy as np
import pygame
import torch
from PIL import Image
from scipy import ndimage

from model import LetterCNN


# ──────────────────────────────────────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────────────────────────────────────

MODEL_PATH = "letter_recognition_model.pth"
DEVICE = torch.device("mps")

# Window dimensions
WINDOW_WIDTH = 600
WINDOW_HEIGHT = 700
CANVAS_SIZE = 500
CANVAS_OFFSET_X = (WINDOW_WIDTH - CANVAS_SIZE) // 2
CANVAS_OFFSET_Y = 160

# Drawing settings
STROKE_COLOR = (255, 255, 255)
STROKE_WIDTH = 14
BACKGROUND_COLOR = (0, 0, 0)

# UI Colors
BG_COLOR = (18, 18, 24)
CANVAS_BORDER_COLOR = (60, 60, 80)
PREDICTION_COLOR = (0, 230, 118)
CONFIDENCE_COLOR = (150, 150, 170)
SUBTITLE_COLOR = (120, 120, 140)
INSTRUCTION_COLOR = (80, 80, 100)

# Prediction debounce (ms) for real-time mode
PREDICTION_DEBOUNCE_MS = 200

# Character mapping — EMNIST Balanced (47 classes)
#   0-9:  digits
#   10-35: uppercase A-Z
#   36-46: lowercase a, b, d, e, f, g, h, n, q, r, t
CHARACTERS = (
    list("0123456789")
    + list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    + list("abdefghnqrt")
)


# ──────────────────────────────────────────────────────────────────────────────
# Model loading
# ──────────────────────────────────────────────────────────────────────────────

def load_model():
    """Load the trained LetterCNN model (47-class)."""
    if not os.path.exists(MODEL_PATH):
        print(f"Error: Model file '{MODEL_PATH}' not found.")
        print("Please run 'python train_model.py' first to train the model.")
        sys.exit(1)

    model = LetterCNN()
    checkpoint = torch.load(MODEL_PATH, map_location=DEVICE, weights_only=True)
    model.load_state_dict(checkpoint["model_state_dict"])
    model.to(DEVICE)
    model.eval()

    accuracy = checkpoint.get("test_accuracy", "N/A")
    epoch = checkpoint.get("epoch", "N/A")
    print(f"Model loaded successfully (epoch {epoch}, test accuracy: {accuracy}%)")

    return model


# ──────────────────────────────────────────────────────────────────────────────
# Preprocessing pipeline
# ──────────────────────────────────────────────────────────────────────────────

def preprocess_canvas(canvas_surface):
    """
    Preprocess the Pygame canvas surface into a model-ready tensor.

    Pipeline:
    1. Convert surface to grayscale numpy array
    2. Crop to bounding box of drawn content
    3. Add proportional padding
    4. Resize to 28×28 (matching EMNIST)
    5. Center by center-of-mass
    6. Normalize to [0, 1]
    7. Convert to PyTorch tensor

    Returns:
        torch.Tensor of shape (1, 1, 28, 28) or None if canvas is blank
    """
    # 1. Convert surface to numpy array (grayscale)
    arr = pygame.surfarray.array3d(canvas_surface)
    # Pygame surfarray gives (width, height, 3) — transpose to (height, width, 3)
    arr = arr.transpose(1, 0, 2)
    # Convert to grayscale
    gray = np.mean(arr, axis=2).astype(np.uint8)

    # Check if canvas is blank
    if gray.max() < 10:
        return None

    # 2. Crop to bounding box
    rows = np.any(gray > 20, axis=1)
    cols = np.any(gray > 20, axis=0)

    if not rows.any() or not cols.any():
        return None

    rmin, rmax = np.where(rows)[0][[0, -1]]
    cmin, cmax = np.where(cols)[0][[0, -1]]

    cropped = gray[rmin:rmax + 1, cmin:cmax + 1]

    # 3. Add proportional padding to make it square with margin
    h, w = cropped.shape
    max_dim = max(h, w)
    # Add 30% padding on each side (like EMNIST format)
    padding = int(max_dim * 0.3)
    target_size = max_dim + 2 * padding

    padded = np.zeros((target_size, target_size), dtype=np.uint8)
    y_offset = (target_size - h) // 2
    x_offset = (target_size - w) // 2
    padded[y_offset:y_offset + h, x_offset:x_offset + w] = cropped

    # 4. Resize to 28×28 using PIL (high-quality downsampling)
    pil_image = Image.fromarray(padded, mode="L")
    pil_image = pil_image.resize((28, 28), Image.LANCZOS)
    resized = np.array(pil_image, dtype=np.float32)

    # 5. Center by center-of-mass (shift content to center of 28×28)
    if resized.sum() > 0:
        cy, cx = ndimage.center_of_mass(resized)
        shift_y = 14 - cy  # 14 = center of 28×28
        shift_x = 14 - cx
        resized = ndimage.shift(resized, [shift_y, shift_x], mode="constant", cval=0)

    # 6. Normalize to [0, 1]
    if resized.max() > 0:
        resized = resized / 255.0

    # 7. Convert to tensor: (1, 1, 28, 28)
    tensor = torch.FloatTensor(resized).unsqueeze(0).unsqueeze(0)

    return tensor


# ──────────────────────────────────────────────────────────────────────────────
# Prediction
# ──────────────────────────────────────────────────────────────────────────────

def predict_letter(model, tensor):
    """
    Run prediction on the preprocessed tensor.

    Returns:
        (predicted_letter, confidence, top3_predictions)
    """
    with torch.no_grad():
        tensor = tensor.to(DEVICE)
        output = model(tensor)
        probabilities = torch.softmax(output, dim=1)

        # Top prediction
        confidence, predicted_idx = probabilities.max(1)
        predicted_char = CHARACTERS[predicted_idx.item()]
        confidence_val = confidence.item() * 100

        # Top 3 predictions
        top3_vals, top3_idxs = probabilities.topk(3, dim=1)
        top3 = []
        for i in range(3):
            char = CHARACTERS[top3_idxs[0][i].item()]
            conf = top3_vals[0][i].item() * 100
            top3.append((char, conf))

    return predicted_char, confidence_val, top3


# ──────────────────────────────────────────────────────────────────────────────
# Drawing App
# ──────────────────────────────────────────────────────────────────────────────

class LetterDrawingApp:
    """Pygame-based drawing app for character recognition."""

    def __init__(self, model):
        pygame.init()
        pygame.display.set_caption("Character Recognition — Draw a Character!")

        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        self.clock = pygame.time.Clock()
        self.model = model

        # Drawing canvas (separate surface)
        self.canvas = pygame.Surface((CANVAS_SIZE, CANVAS_SIZE))
        self.canvas.fill(BACKGROUND_COLOR)

        # State
        self.drawing = False
        self.last_pos = None
        self.predicted_letter = ""
        self.confidence = 0.0
        self.top3 = []
        self.has_drawn = False
        self.last_draw_time = 0

        # Fonts
        self.font_large = pygame.font.SysFont("Segoe UI", 96, bold=True)
        self.font_medium = pygame.font.SysFont("Segoe UI", 28)
        self.font_small = pygame.font.SysFont("Segoe UI", 18)
        self.font_tiny = pygame.font.SysFont("Segoe UI", 15)
        self.font_instruction = pygame.font.SysFont("Segoe UI", 14)

    def clear_canvas(self):
        """Clear the drawing canvas and reset predictions."""
        self.canvas.fill(BACKGROUND_COLOR)
        self.predicted_letter = ""
        self.confidence = 0.0
        self.top3 = []
        self.has_drawn = False
        self.last_pos = None

    def handle_events(self):
        """Process Pygame events. Returns False if app should quit."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_c:
                    self.clear_canvas()
                elif event.key == pygame.K_q:
                    return False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:  # Left click
                    mouse_x, mouse_y = event.pos
                    # Check if click is within canvas bounds
                    if (CANVAS_OFFSET_X <= mouse_x <= CANVAS_OFFSET_X + CANVAS_SIZE and
                            CANVAS_OFFSET_Y <= mouse_y <= CANVAS_OFFSET_Y + CANVAS_SIZE):
                        self.drawing = True
                        # Convert to canvas coordinates
                        cx = mouse_x - CANVAS_OFFSET_X
                        cy = mouse_y - CANVAS_OFFSET_Y
                        self.last_pos = (cx, cy)
                        # Draw a dot at the starting position
                        pygame.draw.circle(
                            self.canvas, STROKE_COLOR, (cx, cy), STROKE_WIDTH // 2
                        )
                        self.has_drawn = True
                        self.last_draw_time = pygame.time.get_ticks()

            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1 and self.drawing:
                    self.drawing = False
                    self.last_pos = None
                    # Trigger prediction on mouse release
                    if self.has_drawn:
                        self._run_prediction()

            elif event.type == pygame.MOUSEMOTION:
                if self.drawing:
                    mouse_x, mouse_y = event.pos
                    # Clamp to canvas bounds
                    cx = max(0, min(mouse_x - CANVAS_OFFSET_X, CANVAS_SIZE - 1))
                    cy = max(0, min(mouse_y - CANVAS_OFFSET_Y, CANVAS_SIZE - 1))

                    if self.last_pos is not None:
                        pygame.draw.line(
                            self.canvas,
                            STROKE_COLOR,
                            self.last_pos,
                            (cx, cy),
                            STROKE_WIDTH,
                        )
                        # Draw circles at endpoints for smooth rounded strokes
                        pygame.draw.circle(
                            self.canvas, STROKE_COLOR, (cx, cy), STROKE_WIDTH // 2
                        )

                    self.last_pos = (cx, cy)
                    self.has_drawn = True
                    self.last_draw_time = pygame.time.get_ticks()

        # Real-time prediction while drawing (debounced)
        if self.drawing and self.has_drawn:
            now = pygame.time.get_ticks()
            if now - self.last_draw_time >= PREDICTION_DEBOUNCE_MS:
                self._run_prediction()
                self.last_draw_time = now

        return True

    def _run_prediction(self):
        """Preprocess canvas and run model prediction."""
        tensor = preprocess_canvas(self.canvas)
        if tensor is not None:
            self.predicted_letter, self.confidence, self.top3 = predict_letter(
                self.model, tensor
            )

    def draw_ui(self):
        """Render the complete UI."""
        self.screen.fill(BG_COLOR)

        # ── Title area ────────────────────────────────────────────────────
        if self.predicted_letter:
            # Predicted letter (large, green, centered)
            letter_surface = self.font_large.render(
                self.predicted_letter, True, PREDICTION_COLOR
            )
            letter_rect = letter_surface.get_rect(
                centerx=WINDOW_WIDTH // 2, centery=50
            )
            self.screen.blit(letter_surface, letter_rect)

            # Confidence
            conf_text = f"{self.confidence:.1f}% confidence"
            conf_surface = self.font_small.render(conf_text, True, CONFIDENCE_COLOR)
            conf_rect = conf_surface.get_rect(
                centerx=WINDOW_WIDTH // 2, centery=105
            )
            self.screen.blit(conf_surface, conf_rect)

            # Top 3 predictions
            if self.top3:
                top3_parts = []
                for letter, conf in self.top3:
                    top3_parts.append(f"{letter}:{conf:.0f}%")
                top3_text = "Top 3:  " + "   ".join(top3_parts)
                top3_surface = self.font_tiny.render(top3_text, True, SUBTITLE_COLOR)
                top3_rect = top3_surface.get_rect(
                    centerx=WINDOW_WIDTH // 2, centery=132
                )
                self.screen.blit(top3_surface, top3_rect)
        else:
            # Prompt
            prompt_surface = self.font_medium.render(
                "Draw a character below", True, SUBTITLE_COLOR
            )
            prompt_rect = prompt_surface.get_rect(
                centerx=WINDOW_WIDTH // 2, centery=70
            )
            self.screen.blit(prompt_surface, prompt_rect)

        # ── Canvas border ─────────────────────────────────────────────────
        border_rect = pygame.Rect(
            CANVAS_OFFSET_X - 2,
            CANVAS_OFFSET_Y - 2,
            CANVAS_SIZE + 4,
            CANVAS_SIZE + 4,
        )
        pygame.draw.rect(self.screen, CANVAS_BORDER_COLOR, border_rect, 2, border_radius=4)

        # ── Canvas ────────────────────────────────────────────────────────
        self.screen.blit(self.canvas, (CANVAS_OFFSET_X, CANVAS_OFFSET_Y))

        # ── Instructions ──────────────────────────────────────────────────
        instructions = [
            "Draw with mouse  •  Press C to clear  •  Press Q to quit",
        ]
        y = CANVAS_OFFSET_Y + CANVAS_SIZE + 16
        for text in instructions:
            instr_surface = self.font_instruction.render(
                text, True, INSTRUCTION_COLOR
            )
            instr_rect = instr_surface.get_rect(centerx=WINDOW_WIDTH // 2, centery=y)
            self.screen.blit(instr_surface, instr_rect)
            y += 22

        pygame.display.flip()

    def run(self):
        """Main application loop."""
        print("App running! Draw a character on the canvas.")
        print("  - Press C to clear")
        print("  - Press Q to quit")

        running = True
        while running:
            running = self.handle_events()
            self.draw_ui()
            self.clock.tick(60)  # 60 FPS

        pygame.quit()


# ──────────────────────────────────────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────────────────────────────────────

def main():
    print("  Character Recognition — Drawing App")
    model = load_model()
    app = LetterDrawingApp(model)
    app.run()


if __name__ == "__main__":
    main()

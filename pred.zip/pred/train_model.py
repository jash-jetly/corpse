import os
import time
import string

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import torchvision
import torchvision.transforms as transforms
from torchvision.transforms import functional as TF

from model import LetterCNN


# ──────────────────────────────────────────────────────────────────────────────
# Configuration
# ──────────────────────────────────────────────────────────────────────────────

BATCH_SIZE = 128
EPOCHS = 12
LEARNING_RATE = 0.001
EARLY_STOP_PATIENCE = 5
SCHEDULER_PATIENCE = 3
SCHEDULER_FACTOR = 0.5
NUM_WORKERS = 0  # Set to 0 for Windows compatibility
DATA_DIR = "./data"
MODEL_SAVE_PATH = "letter_recognition_model.pth"
DEVICE = torch.device("mps")

# Character mapping for EMNIST Balanced (47 classes):
#   0-9:  digits
#   10-35: uppercase A-Z
#   36-46: lowercase a, b, d, e, f, g, h, n, q, r, t
CHARACTERS = (
    list("0123456789")
    + list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
    + list("abdefghnqrt")
)
NUM_CLASSES = len(CHARACTERS)  # 47


# ──────────────────────────────────────────────────────────────────────────────
# Custom transform to fix EMNIST rotation
# ──────────────────────────────────────────────────────────────────────────────

class FixEMNISTOrientation:
    """EMNIST images are transposed — rotate -90° and flip horizontally to fix."""

    def __call__(self, img):
        img = TF.rotate(img, -90)
        img = TF.hflip(img)
        return img


# ──────────────────────────────────────────────────────────────────────────────
# Custom target transform — EMNIST Balanced is already 0-indexed, no shift needed
# ──────────────────────────────────────────────────────────────────────────────


# ──────────────────────────────────────────────────────────────────────────────
# Transforms
# ──────────────────────────────────────────────────────────────────────────────

def get_train_transform():
    """Training transform with heavy augmentation for mouse-drawing robustness."""
    return transforms.Compose([
        FixEMNISTOrientation(),
        # --- Data Augmentation ---
        transforms.RandomRotation(15),
        transforms.RandomAffine(
            degrees=0,
            translate=(0.1, 0.1),
            scale=(0.85, 1.15),
            shear=10,
        ),
        transforms.RandomPerspective(distortion_scale=0.2, p=0.3),
        transforms.GaussianBlur(kernel_size=3, sigma=(0.1, 1.0)),
        # Add elastic-like distortion via random erasing on small patches
        transforms.ToTensor(),
        # Random erasing simulates imperfections in drawing
        transforms.RandomErasing(p=0.1, scale=(0.01, 0.05), ratio=(0.5, 2.0), value=0),
    ])


def get_test_transform():
    """Test transform — only fix orientation and convert to tensor."""
    return transforms.Compose([
        FixEMNISTOrientation(),
        transforms.ToTensor(),
    ])


# ──────────────────────────────────────────────────────────────────────────────
# Dataset loading
# ──────────────────────────────────────────────────────────────────────────────

def load_datasets():
    """Load EMNIST Letters train and test datasets."""
    print("Loading EMNIST Balanced dataset (47 classes)...")

    train_dataset = torchvision.datasets.EMNIST(
        root=DATA_DIR,
        split="balanced",
        train=True,
        download=True,
        transform=get_train_transform(),
    )

    test_dataset = torchvision.datasets.EMNIST(
        root=DATA_DIR,
        split="balanced",
        train=False,
        download=True,
        transform=get_test_transform(),
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=BATCH_SIZE,
        shuffle=True,
        num_workers=NUM_WORKERS,
        pin_memory=False,
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=BATCH_SIZE,
        shuffle=False,
        num_workers=NUM_WORKERS,
        pin_memory=False,
    )

    print(f"  Train samples: {len(train_dataset):,}")
    print(f"  Test samples:  {len(test_dataset):,}")

    return train_loader, test_loader


# ──────────────────────────────────────────────────────────────────────────────
# Training loop
# ──────────────────────────────────────────────────────────────────────────────

def train_one_epoch(model, loader, criterion, optimizer, device):
    """Train for one epoch. Returns (loss, accuracy)."""
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    for batch_idx, (images, labels) in enumerate(loader):
        images, labels = images.to(device), labels.to(device)

        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * images.size(0)
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

        if (batch_idx + 1) % 100 == 0:
            print(f"    Batch {batch_idx + 1}/{len(loader)} | "
                  f"Loss: {loss.item():.4f} | "
                  f"Acc: {100. * correct / total:.2f}%")

    epoch_loss = running_loss / total
    epoch_acc = 100.0 * correct / total
    return epoch_loss, epoch_acc


def evaluate(model, loader, criterion, device):
    """Evaluate on test set. Returns (loss, accuracy, per_class_correct, per_class_total)."""
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0

    per_class_correct = [0] * NUM_CLASSES
    per_class_total = [0] * NUM_CLASSES

    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)

            outputs = model(images)
            loss = criterion(outputs, labels)

            running_loss += loss.item() * images.size(0)
            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

            # Per-class stats
            for i in range(labels.size(0)):
                label = labels[i].item()
                per_class_correct[label] += (predicted[i] == labels[i]).item()
                per_class_total[label] += 1

    epoch_loss = running_loss / total
    epoch_acc = 100.0 * correct / total
    return epoch_loss, epoch_acc, per_class_correct, per_class_total


# ──────────────────────────────────────────────────────────────────────────────
# Main training
# ──────────────────────────────────────────────────────────────────────────────

def main():
    print(f"Using device: {DEVICE}")
    print()

    # Load data
    train_loader, test_loader = load_datasets()
    print()

    # Create model
    model = LetterCNN().to(DEVICE)
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Model: LetterCNN ({total_params:,} parameters)")
    print()

    # Loss, optimizer, scheduler
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode="min",
        patience=SCHEDULER_PATIENCE,
        factor=SCHEDULER_FACTOR,
    )

    # Training
    best_test_acc = 0.0
    epochs_without_improvement = 0

    for epoch in range(1, EPOCHS + 1):
        start_time = time.time()
        current_lr = optimizer.param_groups[0]["lr"]
        print(f"Epoch {epoch}/{EPOCHS} (lr={current_lr:.6f})")
        print("-" * 50)

        # Train
        train_loss, train_acc = train_one_epoch(
            model, train_loader, criterion, optimizer, DEVICE
        )

        # Evaluate
        test_loss, test_acc, per_class_correct, per_class_total = evaluate(
            model, test_loader, criterion, DEVICE
        )

        elapsed = time.time() - start_time

        print(f"  Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.2f}%")
        print(f"  Test  Loss: {test_loss:.4f} | Test  Acc: {test_acc:.2f}%")
        print(f"  Time: {elapsed:.1f}s")

        # Learning rate scheduling
        scheduler.step(test_loss)

        # Save best model
        if test_acc > best_test_acc:
            best_test_acc = test_acc
            epochs_without_improvement = 0

            checkpoint = {
                "model_state_dict": model.state_dict(),
                "test_accuracy": test_acc,
                "epoch": epoch,
                "letters": CHARACTERS,
            }
            torch.save(checkpoint, MODEL_SAVE_PATH)
            print(f"  [*] New best model saved! ({test_acc:.2f}%)")
        else:
            epochs_without_improvement += 1
            print(f"  No improvement for {epochs_without_improvement} epoch(s)")

        print()

        # Early stopping
        if epochs_without_improvement >= EARLY_STOP_PATIENCE:
            print(f"Early stopping triggered after {epoch} epochs.")
            break

    # ── Final report ──────────────────────────────────────────────────────
    print("=" * 60)
    print(f"Training complete! Best test accuracy: {best_test_acc:.2f}%")
    print(f"Model saved to: {MODEL_SAVE_PATH}")
    print()

    # Load best model and show per-class accuracy
    checkpoint = torch.load(MODEL_SAVE_PATH, map_location=DEVICE, weights_only=True)
    model.load_state_dict(checkpoint["model_state_dict"])
    _, _, per_class_correct, per_class_total = evaluate(
        model, test_loader, criterion, DEVICE
    )

    print("Per-class accuracy:")
    print("-" * 40)
    worst_classes = []
    for i in range(NUM_CLASSES):
        if per_class_total[i] > 0:
            acc = 100.0 * per_class_correct[i] / per_class_total[i]
            bar = "#" * int(acc // 2)
            print(f"  {CHARACTERS[i]}: {acc:6.2f}%  {bar}")
            if acc < 80:
                worst_classes.append((CHARACTERS[i], acc))

    if worst_classes:
        print()
        print("[!] Low-accuracy classes (< 80%):")
        for letter, acc in worst_classes:
            print(f"  {letter}: {acc:.2f}%")

    print()
    print("Done! Run 'python app.py' to start the drawing app.")


if __name__ == "__main__":
    main()

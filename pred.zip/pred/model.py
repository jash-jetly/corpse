"""
LetterCNN - Deep Convolutional Neural Network for handwritten character recognition.

Architecture: 4 conv blocks with BatchNorm + Dropout, Global Average Pooling, 2 FC layers.
Input: (1, 28, 28) grayscale image
Output: 47 logits (0-9, A-Z, 11 lowercase letters) — EMNIST Balanced
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class ConvBlock(nn.Module):
    """Double convolution block with BatchNorm, ReLU, MaxPool, and Dropout."""

    def __init__(self, in_channels, out_channels, dropout_rate=0.25):
        super(ConvBlock, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),
            nn.Dropout2d(dropout_rate),
        )

    def forward(self, x):
        return self.block(x)


class LetterCNN(nn.Module):
    """
    Deep CNN for handwritten character recognition (digits, letters).

    Architecture:
        - 4 ConvBlocks: 1→32→64→128→256 channels
        - Global Average Pooling
        - FC(256→512) → ReLU → Dropout → FC(512→47)

    After 4 blocks of MaxPool2d(2,2) on 28×28 input:
        28 → 14 → 7 → 3 → 1
    So the feature map before GAP is (batch, 256, 1, 1).
    """

    NUM_CLASSES = 47  # 0-9, A-Z, 11 lowercase (EMNIST Balanced)

    def __init__(self):
        super(LetterCNN, self).__init__()

        # Convolutional feature extractor
        self.features = nn.Sequential(
            ConvBlock(1, 32, dropout_rate=0.15),
            ConvBlock(32, 64, dropout_rate=0.20),
            ConvBlock(64, 128, dropout_rate=0.25),
            ConvBlock(128, 256, dropout_rate=0.25),
        )

        # Global Average Pooling
        self.gap = nn.AdaptiveAvgPool2d(1)

        # Classifier
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(256, 512),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(512, self.NUM_CLASSES),
        )

    def forward(self, x):
        x = self.features(x)
        x = self.gap(x)
        x = self.classifier(x)
        return x


if __name__ == "__main__":
    # Quick test: verify shapes
    model = LetterCNN()
    dummy = torch.randn(2, 1, 28, 28)
    out = model(dummy)
    print(f"Input shape:  {dummy.shape}")
    print(f"Output shape: {out.shape}")
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Total parameters: {total_params:,}")
